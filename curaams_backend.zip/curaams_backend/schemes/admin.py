from django.contrib import admin
from .models import MedicalScheme

admin.site.register(MedicalScheme)
