from rest_framework import serializers
from .models import MedicalScheme

class MedicalSchemeSerializer(serializers.ModelSerializer):
    class Meta:
        model = MedicalScheme
        fields = '__all__'
