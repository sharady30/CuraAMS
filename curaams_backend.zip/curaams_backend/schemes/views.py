from rest_framework import generics
from .models import MedicalScheme
from .serializers import MedicalSchemeSerializer

class MedicalSchemeListView(generics.ListAPIView):
    queryset = MedicalScheme.objects.all().order_by('-launched_on')
    serializer_class = MedicalSchemeSerializer
