from django.db import models

class MedicalScheme(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    eligibility = models.TextField()
    launched_on = models.DateField()
    link = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.name
