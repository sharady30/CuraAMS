from django.urls import path
from .views import MedicalSchemeListView

urlpatterns = [
    path('schemes/', MedicalSchemeListView.as_view(), name='medical-schemes'),
]
