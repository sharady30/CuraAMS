from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('diseases.urls')),
    path('api/blood/',include('donors.urls')),
    path('api/',include('schemes.urls')),
    
]
