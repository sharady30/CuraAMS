from rest_framework.decorators import api_view
from rest_framework import generics
from rest_framework.response import Response
from .models import Donor, BloodCamp
from .serializers import DonorSerializer,BloodCampSerializer

@api_view(['GET', 'POST'])
def donor_list_create(request):
    if request.method == 'GET':
        donors = Donor.objects.all()
        serializer = DonorSerializer(donors, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = DonorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

class DonorRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Donor.objects.all()
    serializer_class = DonorSerializer

@api_view(['GET'])
def blood_camps(request):
    camps = BloodCamp.objects.all()
    serializer = BloodCampSerializer(camps, many=True)
    return Response(serializer.data)
