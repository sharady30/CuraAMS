from datetime import date
from django.db import models

class Donor(models.Model):
    BLOOD_GROUPS = [
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('O+', 'O+'), ('O-', 'O-'), ('AB+', 'AB+'), ('AB-', 'AB-')
    ]
    
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=10)
    location = models.CharField(max_length=100)
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUPS)
    contact = models.CharField(max_length=15)
    email = models.EmailField(blank=True, null=True)
    last_donation = models.DateField()

    @property
    def available(self):
        days_since_last_donation = (date.today() - self.last_donation).days
        return days_since_last_donation >= 90  # Donor is available if 3 months have passed

    def __str__(self):
        return f"{self.name} ({self.blood_group})"

class BloodCamp(models.Model):
    name = models.CharField(max_length=100)
    organizer = models.CharField(max_length=100)
    venue = models.CharField(max_length=150)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    date = models.DateField()

    def __str__(self):
        return f"{self.name} - {self.city} ({self.date})"
