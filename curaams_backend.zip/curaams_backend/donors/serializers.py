from rest_framework import serializers
from .models import Donor,BloodCamp

class DonorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Donor
        fields = '__all__'

class BloodCampSerializer(serializers.ModelSerializer):
    class Meta:
        model = BloodCamp
        fields = '__all__'

