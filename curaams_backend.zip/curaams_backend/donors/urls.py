from django.urls import path
from .views import donor_list_create,blood_camps
from donors import views

urlpatterns = [
    path('donors/', donor_list_create),
     path('blood/donors/<int:pk>/', views.DonorRetrieveUpdateDestroyView.as_view(), name='donor-retrieve-update-destroy'),
    path('camps/',blood_camps),
]
