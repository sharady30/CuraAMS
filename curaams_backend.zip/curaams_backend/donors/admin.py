from django.contrib import admin
from .models import Donor,BloodCamp

admin.site.register(Donor)
admin.site.register(BloodCamp)
